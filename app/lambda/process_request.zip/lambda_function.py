import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    print(event)


    s3 = boto3.client('s3')

    try:
        s3.upload_file("/etc/resolv.conf","hello.devopssquad.com", "results/bla")
    except Exception as e:
        print(e)
        raise e


    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Origin": "*"
        },
        'body': json.dumps("'out':'Hello brexit'")
    }
